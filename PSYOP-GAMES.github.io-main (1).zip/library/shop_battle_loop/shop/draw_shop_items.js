let dmg_emoji = '💥';

let draw_shop_items = () => {
  //let shop_emojis = ['🪂','🪂','🪂','🪂','🪂'];

  let loop = (l, offset = 0) => {
    if (l.length <= 0) { return }
    let emoji_text = l[0].emoji_text;

    let dmg_text = {
      text: `${dmg_emoji} ${l[0].dmg}`,
      position: {
        x: emoji_text.position.x,
        y: emoji_text.position.y + (10 / 100 * the_canvas.height),
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 4 / 100).toString() + 'px SegoeUI',
    };
    let hp_emoji = '💖';
    let hp_text = {
      text: `${hp_emoji} ${l[0].hp}`,
      position: {
        x: emoji_text.position.x + (6 / 100 * the_canvas.width),
        y: emoji_text.position.y + (10 / 100 * the_canvas.height),
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 4 / 100).toString() + 'px SegoeUI',
    };
    let gold_cost_text = {
      text: `${gold_emoji} 40`,
      position: {
        x: emoji_text.position.x,
        y: emoji_text.position.y + (14 / 100 * the_canvas.height),
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 4 / 100).toString() + 'px SegoeUI',
    };

    add_text(gold_cost_text);
    
    add_text(hp_text);
    //console.warn('shop item x:',emoji_text.position.x);
    add_text(emoji_text);
    add_text(dmg_text);
    loop(rest_of_list(l), offset + 1);
  }
  loop(shop_items);
}