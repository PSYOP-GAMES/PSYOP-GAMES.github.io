let make_buy_button_functional =()=>{
  add_clickable_area_to_text(buy_button_text,()=>{
    console.log('buy button clicked');
    if(shop_items[selected_shop_item_index].emoji_text.text ==='X'){
      console.log('item already bought');
      return;
    }
    buy_user_selected_item_from_shop();
  });
};