let buy_button_emoji = '🪙';
let buy_button_text = {
  text: buy_button_emoji,
  position: {
    x: 45 / 100 * the_canvas.width,
    y: 70/100 * the_canvas.height,
  },
  fillStyle: 'black',
  font: Math.ceil(the_canvas.height * 1.5 / 10).toString() + 'px SegoeUI',
};

let draw_buy_button= () => {
  add_text(buy_button_text);
  // console.warn('draw gold emoji');
}