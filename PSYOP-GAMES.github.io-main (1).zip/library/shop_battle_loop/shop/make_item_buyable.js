let selected_shop_item = undefined;
let make_item_buyable =(item,item_text,index)=>{
  if(item_text===undefined){console.warn('item_text param undefined');}
  add_clickable_area_to_text(
    item_text,
    ()=>{
      console.log(item.em + ' clicked!');
      // shop item clicked
      // item selected
      // set selection
      selected_shop_item = item;
      selected_shop_item_index = index;
      console.log('index',index);
      // draw selection
    });
}