let players_team_emoji = '😃';
let draw_players_team = () => {
  let loop = (l, n = 0) => {
    if (l.length <= 0) { return }

    text = {
      text: l[0].em,
      position: {
        x: ((15 / 100) + (10 / 100 * n)) * the_canvas.width,
        y: 85 / 100 * the_canvas.height,
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 1.5 / 10).toString() + 'px SegoeUI',
    };
    
    l[0].emoji_text = text;
    let emoji_text = text;
    let dmg_text = {
      text: `${dmg_emoji} ${l[0].dmg}`,
      position: {
        x: emoji_text.position.x,
        y: emoji_text.position.y + (10 / 100 * the_canvas.height),
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 4 / 100).toString() + 'px SegoeUI',
    };
    
    
    let hp_emoji = '💖';
    let hp_text = {
      text: `${hp_emoji} ${l[0].hp}`,
      position: {
        x: emoji_text.position.x + (6 / 100 * the_canvas.width),
        y: emoji_text.position.y + (10 / 100 * the_canvas.height),
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 4 / 100).toString() + 'px SegoeUI',
    };
    
    //l[0].emoji_text = 
    add_text(text);
    
    if (l[0].dmg !== undefined) {
      add_text(hp_text);
      add_text(dmg_text);
    }
    
    loop(rest_of_list(l), n + 1);
  }
  loop([
    { em: players_team_emoji },
    { em:'|'},
    ...the_players_team,
    ]);
};