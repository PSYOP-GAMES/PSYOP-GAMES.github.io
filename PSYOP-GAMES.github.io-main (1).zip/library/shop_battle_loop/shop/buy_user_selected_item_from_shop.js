let buy_user_selected_item_from_shop =()=>{
  if(the_player.gold < selected_shop_item.price){
   console.log('not enough gold',the_player.gold,selected_shop_item.price);
   return;
  }
  the_player.gold -= selected_shop_item.price;
  let remove_shop_item =(i)=>{
    shop_items[i] = {...shop_items[i]};
    shop_items[i].emoji_text.text ='X';
  }
  remove_shop_item(selected_shop_item_index);
  the_player.inventory.push(selected_shop_item);
}