let players_inventory_emoji = '📋';
let draw_players_inventory=()=> {
  let loop=(l,n=0)=>{
    if(l.length<=0){return}
    
    text = {
      text: l[0].em,
      position: {
        x: ((15 / 100)+(10/100*n))* the_canvas.width,
        y: 90 / 100 * the_canvas.height,
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 1.5 / 10).toString() + 'px SegoeUI',
    };
    //l[0].emoji_text = 
    add_text(text);
    loop(rest_of_list(l),n+1);
  }
  loop([
    {em:players_inventory_emoji},
    {em:'['},
    ...the_player.inventory,
    {em:']'}]);
  
}