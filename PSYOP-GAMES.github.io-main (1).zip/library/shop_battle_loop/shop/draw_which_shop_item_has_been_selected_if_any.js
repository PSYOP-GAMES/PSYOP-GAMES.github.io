let draw_which_shop_item_has_been_selected_if_any =()=>{
  if(selected_shop_item===undefined){
    return;
  }
  
  item_text = selected_shop_item.emoji_text;
  let ctx = the_canvas.ctx;
  ctx.strokeStyle = 'black';
  ctx.lineWidth = 4;
  ctx.strokeRect(
    item_text.position.x,
    item_text.position.y - item_text.height,
    item_text.width, //item_text.width,  
    item_text.height, //item_text.height
  );
}