
// domt use this function
let run_autobattler_game_old= () => {
  draw_functions = [
    clear_canvas,
    draw_player,
    draw_enemy,
  ];
  establish_player();
  establish_enemy();
}

let the_players_lives = 0;
let matches_won = 0;
let rounds_won = 0;
let the_number_of_rounds_needed_to_beat_the_game = 2;
let run_autobattler_game =()=>{
  rounds_won = 0;
  the_players_lives = 1;
  the_player.inventory =[];
  
  // shop battle loop
  run_shop(); // which will then run the battle
};

//run_autobattler_game();
