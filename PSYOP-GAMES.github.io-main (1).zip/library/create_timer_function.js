let create_repeating_timer_function =(interval,f,log_text='unset')=>{
  console.log('create repeating timer function: '+log_text);
  let time_passed = 0;
  return (t)=>{
    time_passed += t;
    if(time_passed >= interval){
      time_passed -= interval;
      f();
    }
  }
}
//console.log('end of create timer function');
let create_one_off_timer_function =(interval,f,log_text='unset')=>{
  console.log('create one off timer function: '+log_text);
  let time_passed = 0;
  let activated = false;
  return (t)=>{
    time_passed += t;
    if(time_passed >= interval){
      if(activated){}
      else{ 
        activated = true;
        f();}
    }
  }
}
//console.log('end of create timer function');

let one_time =(i,f,log)=> {
  update_functions.push(
    create_one_off_timer_function(i,f,log)
    );
};
