let make_start_battle_button_clickable =()=>{
  add_clickable_area_to_text(start_battle_button_text,()=>{
    console.log('start battle button clicked');
    start_battle();
  });
}