let starting_battle_text = {
  text: 'STARTING       BATTLE',
  position: {
    x: 5 / 100 * the_canvas.width,
    y: 1 / 8 * the_canvas.height,
  },
  fillStyle: 'black',
  font: Math.ceil(the_canvas.height * 1 / 10).toString() + 'px SegoeUI',
};

let draw_starting_battle_text= () => {
  add_text(starting_battle_text);
  // console.warn('draw gold emoji');
}