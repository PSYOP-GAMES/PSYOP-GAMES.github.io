let deck = [
 {em:'🪂',hp:1,dmg:1,price:30},
 {em:'🛰️',hp:1,dmg:3,price:30},
 {em:'🚢',hp:3,dmg:1,price:30},
 ];

let shop_items =[];
let repeat=(n,f)=>{
  if(n<=0){ return }
  else{
    f(n);
    repeat(n-1,f)}}

let reroll_cost = 25;

let roll_shop =(cost)=>{
  cost = cost===undefined? reroll_cost :cost;
  if(the_player.gold < cost){
    // draw not enough gold warning
    return;
  }
  the_player.gold -= cost;
  shop_items =[];
  repeat(5,(n)=> { 
    //let offset =  5-n;
    //console.log('offset:',offset);
    let item = {...random(deck)};
    
    item.emoji_text = {
      text: item.em,
      position: {
        x: Math.floor(((10/100)+(16/ 100*(5-n))) * the_canvas.width),
        y: 33 / 100 * the_canvas.height,
      },
      fillStyle: 'black',
      font: Math.ceil(the_canvas.height * 16 / 100).toString() + 'px SegoeUI',
    };
    //console.log('shop item x',item.emoji_text.position.x);
    
    shop_items.push(item);
    make_item_buyable(item,item.emoji_text,5-n);
  });
  console.log("shop merch: ",shop_items);
  }

let reroll = roll_shop;
let reroll_shop = roll_shop;
