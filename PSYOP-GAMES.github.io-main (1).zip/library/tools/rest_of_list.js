let rest_of_list = l => {
  return l.slice(1);
}