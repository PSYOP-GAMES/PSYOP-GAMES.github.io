let start_battle_button_emoji = '➡️';
let start_battle_button_text = {
  text: start_battle_button_emoji,
  position: {
    x: 90/ 100 * the_canvas.width,
    y: 95 / 100 * the_canvas.height,
  },
  fillStyle: 'black',
  font: Math.ceil(the_canvas.height * 1.5 / 10).toString() + 'px SegoeUI',
};

let draw_start_battle_button = () => {
  add_text(start_battle_button_text);
  // console.warn('draw gold emoji');
}