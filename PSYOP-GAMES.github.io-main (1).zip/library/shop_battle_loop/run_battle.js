let the_players_team = [];
let total_games_won =0;
let run_battle=()=>{
  let wait_then = one_time;
  
  console.log('running battle');
  update_functions =[];
  draw_functions =[
    clear_canvas,
    draw_starting_battle_text];
   
  // make a copy of the players inventory
  let copy_list_of_objects =(l)=>{
    if(l.length <= 0){
      return [];
    }
    else{
      return [{...l[0]}].concat(copy_list_of_objects(rest_of_list(l)));
    }
  }
  the_players_team = copy_list_of_objects(the_player.inventory);
  
  select_opponent_team();
  
  let battle_loop =()=>{
    let choose_next_battler=(l)=>{
      if(l.length<=0){ return 'no more'; }
      if(l[0].emoji_text.text ==='X'){
        return choose_next_battler(rest_of_list(l));
      }
      return l[0];
    }
    
    let p = choose_next_battler(the_players_team);
    let o = choose_next_battler(opponents_team);
    console.log(p,'  vs  ',o);
    
    let win=()=>{
      rounds_won+=1;
      // wait then display win
      update_functions=[];
      
      let credit_the_win_to_the_players_account =()=>{
        total_games_won+=1;
      }
      
      let launch_win_game_screen=()=>{
          let wint_text = {
            text: "W I N N E R",
            position: {
              x: 5 / 100 * the_canvas.width,
              y: 50 / 100 * the_canvas.height,
            },
            fillStyle: 'black',
            font: Math.ceil(the_canvas.height * 1 / 10).toString() + 'px SegoeUI',
          };
          
        draw_functions = [
          clear_canvas,
          ()=>add_text(wint_text)];
          
        wait_then(4000,run_main_menu);
      }
      
      let decide_if_we_are_going_back_to_the_shop_or_ending_the_game =()=>{
        if(rounds_won > the_number_of_rounds_needed_to_beat_the_game){
          credit_the_win_to_the_players_account();
          launch_win_game_screen();
        }
        else{
          run_shop();
        }
      }
      
      let display_win =()=>{
        
        let win_text = {
          text: "Congratulations you've won the round.",
          position: {
            x: 5 / 100 * the_canvas.width,
            y: 50/100 * the_canvas.height,
          },
          fillStyle: 'black',
          font: Math.ceil(the_canvas.height * 1 / 10).toString() + 'px SegoeUI',
        };
        
        
        draw_functions = [
          clear_canvas,
          ()=>add_text(win_text)];
          
        wait_then(2000,decide_if_we_are_going_back_to_the_shop_or_ending_the_game);
      }
      wait_then(1000,display_win);
    }
    let lose =()=>{
      let launch_lose_game_screen = () => {
        let win_text = {
          text: "L O S E",
          position: {
            x: 5 / 100 * the_canvas.width,
            y: 50 / 100 * the_canvas.height,
          },
          fillStyle: 'black',
          font: Math.ceil(the_canvas.height * 1 / 10).toString() + 'px SegoeUI',
        };
     
        draw_functions = [
          clear_canvas,
          ()=>add_text(win_text)];
          
        wait_then(4000, run_shop);
      }
      wait_then(1000,launch_lose_game_screen);
    }
    let tie = () => {
      let launch_tie_screen = () => {
        let win_text = {
          text: "T I E",
          position: {
            x: 5 / 100 * the_canvas.width,
            y: 50 / 100 * the_canvas.height,
          },
          fillStyle: 'black',
          font: Math.ceil(the_canvas.height * 1 / 10).toString() + 'px SegoeUI',
        };
        
        draw_functions.push(()=>add_text(win_text));
       
        wait_then(700,()=>{
          draw_functions = [
            clear_canvas,
            ()=>add_text(win_text)]; });
          
        wait_then(1800, run_shop);
      }
      wait_then(100, launch_tie_screen);
    }
    
    if((p==='no more') && (o==='no more')){
      console.log('tie');
      one_time(100,tie,'draw game   run main menu');
      return;
    }
    if (p === 'no more') {
      console.log('lose');
      one_time(1000, lose, 'lost game   run main menu');
      return;
    }
    if (o === 'no more'){
      console.log('win');
      one_time(1000, win, 'won game   run main menu');
      return;
    }
    
    // damage opponent
    o.hp -= p.dmg;
    // damage player
    p.hp -= o.dmg;
    
    update_functions.push(create_one_off_timer_function(1000,()=>{
     let kill =x=>{ 
       x.em='X';};
     let kill_if_no_hp =x=>{ 
       if(x.hp <=0){
         console.log('kill');
         kill(x);
       }};
     kill_if_no_hp(o);
     kill_if_no_hp(p);
       
     update_functions.push(create_one_off_timer_function(1000,()=>{
           battle_loop()}));
    }));
  };
  
  update_functions.push(create_one_off_timer_function(1000,()=>{
    draw_functions =[
      clear_canvas,
      draw_players_team,
      draw_opponents_team,
      ];
     // after x seconds 
     update_functions.push(create_one_off_timer_function(1500,()=>{
        battle_loop();
     }));
  }));
};
let start_battle=run_battle;
