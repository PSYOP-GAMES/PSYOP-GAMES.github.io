let add = (e) => {
  let x = document.createElement(e);
  document.body.appendChild(x);
  return x;
}

let go_fullscreen=()=> {
  //var elem = document.documentElement;
  let elem = the_canvas;
  
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.msRequestFullscreen) {
    elem.msRequestFullscreen();
  } else if (elem.mozRequestFullScreen) {
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) {
    elem.webkitRequestFullscreen();
  }
};

let create_canvas = () => {
  let c = add('canvas');
  c.ctx = c.getContext('2d');
//  c.width = window.screen.width;
//  c.height = 80/100*window.screen.height;
  //c.width = "100%";
  //c.width=1600;
  //c.height =720*0.85;
  c.background = (color) => {
    c.ctx.fillStyle = color;
    c.ctx.fillRect(0, 0, c.width, c.height);
  }
  return c;
}

let the_canvas = create_canvas();
