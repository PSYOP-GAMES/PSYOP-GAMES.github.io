let gold_emoji = '💰';
let gold_emoji_text ={
  text: gold_emoji,
  position: {
    x: 5/100 * the_canvas.width,
    y: 1 / 8 * the_canvas.height,
  },
  fillStyle: 'black',
  font: Math.ceil(the_canvas.height*1/10).toString()+'px SegoeUI',
};

let draw_gold_emoji=()=>{
  add_text(gold_emoji_text);
 // console.warn('draw gold emoji');
}
let draw_number_that_represents_the_players_gold =()=>{
  let gold_amount_text = {
    text: the_player.gold.toString(),
    position: {
      x: gold_emoji_text.position.x+((6/100)* the_canvas.width),
      y: gold_emoji_text.position.y,
    },
    fillStyle: 'black',
    font: gold_emoji_text.font,
  };
  add_text(gold_amount_text);
}



let dice_emoji = '🎲';
let reroll_shop_text ={
  text: dice_emoji,
  position: {
    x: 80/100* the_canvas.width,
    y: 70/100 * the_canvas.height,
  },
  fillStyle: 'black',
  font: Math.ceil(the_canvas.height*15/100).toString()+'px SegoeUI',
};
let draw_die_to_represent_rerolling_the_shop=()=>{
  add_text(reroll_shop_text);
};
//ok
let run_shop =()=>{
  update_functions = [];
  //the_player.inventory =[];
  the_player.gold = 100;
  roll_shop(0);
  draw_functions = [
    clear_canvas,
    draw_gold_emoji,
    draw_number_that_represents_the_players_gold,
    draw_shop_items,
    draw_which_shop_item_has_been_selected_if_any,
    draw_die_to_represent_rerolling_the_shop,
    draw_buy_button,
    draw_players_inventory,
    draw_start_battle_button,
    
  ];
  console.log('adding shop roll button');
  add_clickable_area_to_text(reroll_shop_text,roll_shop);
  make_buy_button_functional();
  make_start_battle_button_clickable();
};
